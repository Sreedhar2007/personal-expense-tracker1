using System.Collections.Generic;
using UnityEngine;

namespace Hollowmere.Gen
{
    /// <summary>
    /// Transforms blocky procedural layouts into detailed, believable abandoned horror-facility environments.
    /// Handles architectural trims, thematic room dressing, and environmental props while strictly preserving
    /// grid walkability, cover mechanics, and AI line of sight rules.
    /// </summary>
    public static class RoomDecorator
    {
        public static void DecorateFacility(LevelData data, Transform root, System.Random rng)
        {
            var grid = data.Grid;
            float cellSize = LevelGenerator.CellSize;
            float wallH = LevelGenerator.WallHeight;

            var archParent = new GameObject("ArchitecturalDetails").transform;
            archParent.SetParent(root, false);

            var propsParent = new GameObject("FacilityProps").transform;
            propsParent.SetParent(root, false);

            var lightsParent = new GameObject("CeilingFixtures").transform;
            lightsParent.SetParent(root, false);

            // 1. Wall Baseboards on all exposed interior wall faces
            BuildBaseboards(grid, archParent, cellSize, wallH);

            // 2. Doorway Frames at all corridor-to-room transitions
            BuildDoorwayPortals(data, archParent, cellSize);

            // 3. Overhead Industrial Conduits & Ceiling Lighting
            BuildCeilingFixturesAndPipes(data, lightsParent, archParent, rng, cellSize, wallH);

            // 4. Thematic Room Dressing (Spawn office, medical ward, storage, labs)
            BuildThematicRooms(data, propsParent, rng, cellSize);

            // 5. Corridor Clutter
            BuildCorridorDetails(data, propsParent, rng, cellSize);
        }

        // --- Architectural Details -------------------------------------------

        static void BuildBaseboards(LevelGrid grid, Transform parent, float cellSize, float wallH)
        {
            const float baseH = 0.16f;
            const float baseThick = 0.045f;
            var baseMat = EnhancedMaterials.Baseboard;

            for (int y = 0; y < grid.Height; y++)
            {
                for (int x = 0; x < grid.Width; x++)
                {
                    if (grid.IsWalkable(x, y)) continue;

                    var cellCenter = grid.CellToWorld(x, y);

                    // North wall face
                    if (grid.InBounds(x, y + 1) && grid.IsWalkable(x, y + 1))
                    {
                        var pos = new Vector3(cellCenter.x, baseH * 0.5f, cellCenter.z + cellSize * 0.5f - baseThick * 0.5f);
                        FacilityProps.MakePart(parent, "Baseboard_N", pos, new Vector3(cellSize, baseH, baseThick), baseMat);
                    }
                    // South wall face
                    if (grid.InBounds(x, y - 1) && grid.IsWalkable(x, y - 1))
                    {
                        var pos = new Vector3(cellCenter.x, baseH * 0.5f, cellCenter.z - cellSize * 0.5f + baseThick * 0.5f);
                        FacilityProps.MakePart(parent, "Baseboard_S", pos, new Vector3(cellSize, baseH, baseThick), baseMat);
                    }
                    // East wall face
                    if (grid.InBounds(x + 1, y) && grid.IsWalkable(x + 1, y))
                    {
                        var pos = new Vector3(cellCenter.x + cellSize * 0.5f - baseThick * 0.5f, baseH * 0.5f, cellCenter.z);
                        FacilityProps.MakePart(parent, "Baseboard_E", pos, new Vector3(baseThick, baseH, cellSize), baseMat);
                    }
                    // West wall face
                    if (grid.InBounds(x - 1, y) && grid.IsWalkable(x - 1, y))
                    {
                        var pos = new Vector3(cellCenter.x - cellSize * 0.5f + baseThick * 0.5f, baseH * 0.5f, cellCenter.z);
                        FacilityProps.MakePart(parent, "Baseboard_W", pos, new Vector3(baseThick, baseH, cellSize), baseMat);
                    }
                }
            }
        }

        static void BuildDoorwayPortals(LevelData data, Transform parent, float cellSize)
        {
            var grid = data.Grid;

            for (int r = 0; r < data.Rooms.Count; r++)
            {
                var room = data.Rooms[r];

                // Check West & East borders
                for (int cy = room.yMin; cy < room.yMax; cy++)
                {
                    // West entrance
                    if (grid.InBounds(room.xMin - 1, cy) && grid.IsWalkable(room.xMin - 1, cy))
                    {
                        var pos = grid.CellToWorld(room.xMin, cy) + new Vector3(-cellSize * 0.5f, 0f, 0f);
                        FacilityProps.CreateDoorwayFrame(parent, pos, Quaternion.Euler(0f, 90f, 0f));
                    }
                    // East entrance
                    if (grid.InBounds(room.xMax, cy) && grid.IsWalkable(room.xMax, cy))
                    {
                        var pos = grid.CellToWorld(room.xMax - 1, cy) + new Vector3(cellSize * 0.5f, 0f, 0f);
                        FacilityProps.CreateDoorwayFrame(parent, pos, Quaternion.Euler(0f, 90f, 0f));
                    }
                }

                // Check South & North borders
                for (int cx = room.xMin; cx < room.xMax; cx++)
                {
                    // South entrance
                    if (grid.InBounds(cx, room.yMin - 1) && grid.IsWalkable(cx, room.yMin - 1))
                    {
                        var pos = grid.CellToWorld(cx, room.yMin) + new Vector3(0f, 0f, -cellSize * 0.5f);
                        FacilityProps.CreateDoorwayFrame(parent, pos, Quaternion.identity);
                    }
                    // North entrance
                    if (grid.InBounds(cx, room.yMax) && grid.IsWalkable(cx, room.yMax))
                    {
                        var pos = grid.CellToWorld(cx, room.yMax - 1) + new Vector3(0f, 0f, cellSize * 0.5f);
                        FacilityProps.CreateDoorwayFrame(parent, pos, Quaternion.identity);
                    }
                }
            }
        }

        // --- Lighting & Overhead Infrastructure ------------------------------

        static void BuildCeilingFixturesAndPipes(LevelData data, Transform lightParent, Transform archParent, System.Random rng, float cellSize, float wallH)
        {
            // Room ceiling fixtures
            for (int i = 0; i < data.Rooms.Count; i++)
            {
                var room = data.Rooms[i];
                var center = data.PatrolPoints[i];

                bool lightFlickers = rng.NextDouble() > 0.65;
                var fixturePos = center + new Vector3(0f, wallH, 0f);
                var rot = room.width >= room.height ? Quaternion.Euler(0f, 90f, 0f) : Quaternion.identity;

                FacilityProps.CreateFluorescentFixture(lightParent, fixturePos, rot, lightFlickers, rng);

                // Overhead conduit running across ceiling
                Vector3 pipeStart = new Vector3(room.xMin * cellSize, wallH - 0.15f, center.z);
                Vector3 pipeEnd = new Vector3((room.xMax - 1) * cellSize, wallH - 0.15f, center.z);
                FacilityProps.CreateOverheadPipe(archParent, pipeStart, pipeEnd, 0.07f);

                // Hanging wires in some rooms
                if (rng.NextDouble() > 0.55)
                {
                    FacilityProps.CreateHangingWires(archParent, center + new Vector3(0.7f, wallH, 0.4f), 0.85f);
                }
            }
        }

        // --- Room Dressing ---------------------------------------------------

        enum RoomTheme { SecurityOffice, MedicalWard, StorageBay, ResearchLab }

        static void BuildThematicRooms(LevelData data, Transform parent, System.Random rng, float cellSize)
        {
            var grid = data.Grid;

            for (int i = 0; i < data.Rooms.Count; i++)
            {
                var room = data.Rooms[i];
                RoomTheme theme;

                if (i == 0) theme = RoomTheme.SecurityOffice; // Player spawn room
                else if (i % 3 == 1) theme = RoomTheme.MedicalWard;
                else if (i % 3 == 2) theme = RoomTheme.StorageBay;
                else theme = RoomTheme.ResearchLab;

                DecorateSingleRoom(grid, room, theme, parent, rng, cellSize);
            }
        }

        static void DecorateSingleRoom(LevelGrid grid, RectInt room, RoomTheme theme, Transform parent, System.Random rng, float cellSize)
        {
            var solidWest = new List<Vector2Int>();
            var solidEast = new List<Vector2Int>();
            var solidSouth = new List<Vector2Int>();
            var solidNorth = new List<Vector2Int>();

            for (int y = room.yMin + 1; y < room.yMax - 1; y++)
            {
                if (grid.InBounds(room.xMin - 1, y) && !grid.IsWalkable(room.xMin - 1, y))
                    solidWest.Add(new Vector2Int(room.xMin, y));
                if (grid.InBounds(room.xMax, y) && !grid.IsWalkable(room.xMax, y))
                    solidEast.Add(new Vector2Int(room.xMax - 1, y));
            }

            for (int x = room.xMin + 1; x < room.xMax - 1; x++)
            {
                if (grid.InBounds(x, room.yMin - 1) && !grid.IsWalkable(x, room.yMin - 1))
                    solidSouth.Add(new Vector2Int(x, room.yMin));
                if (grid.InBounds(x, room.yMax) && !grid.IsWalkable(x, room.yMax))
                    solidNorth.Add(new Vector2Int(x, room.yMax - 1));
            }

            switch (theme)
            {
                case RoomTheme.SecurityOffice:
                    DressSecurityOffice(grid, solidWest, solidEast, solidNorth, parent, rng, cellSize);
                    break;
                case RoomTheme.MedicalWard:
                    DressMedicalWard(grid, solidWest, solidEast, solidSouth, parent, rng, cellSize);
                    break;
                case RoomTheme.StorageBay:
                    DressStorageBay(grid, solidWest, solidEast, solidSouth, solidNorth, parent, rng, cellSize);
                    break;
                case RoomTheme.ResearchLab:
                    DressResearchLab(grid, solidWest, solidEast, solidNorth, parent, rng, cellSize);
                    break;
            }
        }

        static void DressSecurityOffice(LevelGrid grid, List<Vector2Int> solidW, List<Vector2Int> solidE, List<Vector2Int> solidN, Transform parent, System.Random rng, float cellSize)
        {
            if (solidW.Count > 0)
            {
                var cell = solidW[0];
                var deskPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(-cellSize * 0.5f + 0.55f, 0f, 0f);
                FacilityProps.CreateOfficeDesk(parent, deskPos, Quaternion.Euler(0f, 90f, 0f), rng);

                var chairPos = deskPos + new Vector3(0.75f, 0f, 0f);
                FacilityProps.CreateOfficeChair(parent, chairPos, Quaternion.Euler(0f, -90f, 0f), false);

                // Wastebasket beside desk
                FacilityProps.CreateTrashCan(parent, deskPos + new Vector3(0.5f, 0f, 0.7f), rng);

                // Evacuation plaque on the wall above the desk
                var plaquePos = grid.CellToWorld(cell.x, cell.y) + new Vector3(-cellSize * 0.5f + 0.04f, 1.9f, 0f);
                FacilityProps.CreateWallPlaque(parent, plaquePos, Quaternion.Euler(0f, 90f, 0f), EnhancedMaterials.Paper, new Vector2(0.6f, 0.45f));

                // HVAC intake vent up on wall
                var ventPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(-cellSize * 0.5f + 0.04f, 2.75f, 0.75f);
                FacilityProps.CreateVentGrill(parent, ventPos, Quaternion.Euler(0f, 90f, 0f));
            }

            if (solidE.Count > 0)
            {
                var cell = solidE[0];
                var cabPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(cellSize * 0.5f - 0.4f, 0f, 0f);
                FacilityProps.CreateFilingCabinet(parent, cabPos, Quaternion.Euler(0f, -90f, 0f), true);

                FacilityProps.CreateFloorDebris(parent, cabPos + new Vector3(-0.6f, 0f, 0f), rng);
            }
        }

        static void DressMedicalWard(LevelGrid grid, List<Vector2Int> solidW, List<Vector2Int> solidE, List<Vector2Int> solidS, Transform parent, System.Random rng, float cellSize)
        {
            if (solidW.Count > 0)
            {
                var cell = solidW[0];
                var cotPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(-cellSize * 0.5f + 0.65f, 0f, 0f);
                FacilityProps.CreateMedicalCot(parent, cotPos, Quaternion.Euler(0f, 90f, 0f));

                // Blood puddle on floor near cot
                FacilityProps.CreateBloodSpatter(parent, cotPos + new Vector3(0.45f, 0f, -0.6f), Quaternion.identity, new Vector2(0.85f, 0.7f));

                // Biohazard sign on the wall
                var signPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(-cellSize * 0.5f + 0.04f, 1.85f, 0f);
                FacilityProps.CreateWallPlaque(parent, signPos, Quaternion.Euler(0f, 90f, 0f), EnhancedMaterials.Biohazard, new Vector2(0.5f, 0.5f));
            }

            if (solidE.Count > 0)
            {
                var cell = solidE[0];
                var shelfPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(cellSize * 0.5f - 0.35f, 0f, 0f);
                FacilityProps.CreateIndustrialShelving(parent, shelfPos, Quaternion.Euler(0f, -90f, 0f), rng);
            }
        }

        static void DressStorageBay(LevelGrid grid, List<Vector2Int> solidW, List<Vector2Int> solidE, List<Vector2Int> solidS, List<Vector2Int> solidN, Transform parent, System.Random rng, float cellSize)
        {
            if (solidW.Count > 0)
            {
                var cell = solidW[0];
                var shelfPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(-cellSize * 0.5f + 0.35f, 0f, 0f);
                FacilityProps.CreateIndustrialShelving(parent, shelfPos, Quaternion.Euler(0f, 90f, 0f), rng);
            }

            if (solidE.Count > 0)
            {
                var cell = solidE[0];
                var shelfPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(cellSize * 0.5f - 0.35f, 0f, 0f);
                FacilityProps.CreateIndustrialShelving(parent, shelfPos, Quaternion.Euler(0f, -90f, 0f), rng);
            }

            if (solidS.Count > 0)
            {
                var cell = solidS[0];
                var cratePos = grid.CellToWorld(cell.x, cell.y) + new Vector3(0f, 0.45f, -cellSize * 0.5f + 0.55f);
                var crate = LevelGenerator.MakeBox(parent, "StorageCrate", cratePos, new Vector3(0.95f, 0.9f, 0.95f), EnhancedMaterials.Cardboard);
                crate.isStatic = true;

                // High-voltage caution plate above crate
                var voltPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(0f, 1.8f, -cellSize * 0.5f + 0.04f);
                FacilityProps.CreateWallPlaque(parent, voltPos, Quaternion.identity, EnhancedMaterials.HighVoltage, new Vector2(0.5f, 0.5f));
            }
        }

        static void DressResearchLab(LevelGrid grid, List<Vector2Int> solidW, List<Vector2Int> solidE, List<Vector2Int> solidN, Transform parent, System.Random rng, float cellSize)
        {
            if (solidW.Count > 0)
            {
                var cell = solidW[0];
                var benchPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(-cellSize * 0.5f + 0.55f, 0f, 0f);
                FacilityProps.CreateLabCounter(parent, benchPos, Quaternion.Euler(0f, 90f, 0f), rng);

                // Research whiteboard on the wall above counter
                var boardPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(-cellSize * 0.5f + 0.04f, 1.95f, 0f);
                FacilityProps.CreateWhiteboard(parent, boardPos, Quaternion.Euler(0f, 90f, 0f), new Vector2(1.8f, 0.85f));
            }

            if (solidE.Count > 0)
            {
                var cell = solidE[0];
                var cabPos = grid.CellToWorld(cell.x, cell.y) + new Vector3(cellSize * 0.5f - 0.4f, 0f, 0f);
                FacilityProps.CreateFilingCabinet(parent, cabPos, Quaternion.Euler(0f, -90f, 0f), false);
            }
        }

        static void BuildCorridorDetails(LevelData data, Transform parent, System.Random rng, float cellSize)
        {
            for (int i = 0; i < data.Rooms.Count; i++)
            {
                var room = data.Rooms[i];
                var entrancePos = data.Grid.CellToWorld(room.xMin, room.yMin) + new Vector3(0.5f, 0f, 0.5f);

                if (rng.NextDouble() > 0.40)
                {
                    FacilityProps.CreateFloorDebris(parent, entrancePos, rng);
                }

                // Illuminated exit signs above room doorways in some corridors
                if (i % 2 == 1)
                {
                    var exitSignPos = entrancePos + new Vector3(0f, 2.85f, -0.6f);
                    FacilityProps.CreateExitSign(parent, exitSignPos, Quaternion.identity);
                }
            }
        }
    }
}
