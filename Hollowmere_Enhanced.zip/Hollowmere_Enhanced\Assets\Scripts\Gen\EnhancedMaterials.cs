using System.Collections.Generic;
using UnityEngine;

namespace Hollowmere.Gen
{
    /// <summary>
    /// Advanced procedural PBR material generator for abandoned facility environments.
    /// Generates high-fidelity Albedo, Tangent-Space Normal Maps, and Metallic-Smoothness maps
    /// at runtime over Unity's Standard shader. Retains zero external asset dependencies.
    /// </summary>
    public static class EnhancedMaterials
    {
        static readonly Dictionary<string, Material> Cache = new Dictionary<string, Material>();

        static Shader StandardShader
        {
            get
            {
                var s = Shader.Find("Standard");
                if (s == null) s = Shader.Find("Diffuse");
                return s;
            }
        }

        // --- Public Material Library -----------------------------------------

        public static Material FacilityWall => Get("facility_wall", BuildWallMaterial);
        public static Material TileFloor => Get("facility_tile_floor", BuildTileFloorMaterial);
        public static Material CeilingGrid => Get("facility_ceiling_grid", BuildCeilingGridMaterial);
        public static Material PaintedMetal => Get("facility_painted_metal", BuildPaintedMetalMaterial);
        public static Material DarkWood => Get("facility_dark_wood", BuildWoodMaterial);
        public static Material Paper => Get("facility_paper", BuildPaperMaterial);
        public static Material HazardStripe => Get("facility_hazard_stripe", BuildHazardMaterial);
        public static Material Biohazard => Get("facility_biohazard", BuildBiohazardMaterial);
        public static Material Cardboard => Get("facility_cardboard", BuildCardboardMaterial);
        public static Material PipeMetal => Get("facility_pipe_metal", BuildPipeMaterial);
        public static Material Mattress => Get("facility_mattress", BuildMattressMaterial);
        public static Material Baseboard => Get("facility_baseboard", () => BuildFlatMaterial(new Color(0.12f, 0.12f, 0.13f), 0.35f, 0.5f));
        public static Material Chrome => Get("facility_chrome", () => BuildFlatMaterial(new Color(0.85f, 0.85f, 0.88f), 0.85f, 0.95f));
        public static Material BloodStain => Get("facility_blood_stain", BuildBloodMaterial);
        public static Material VentLouver => Get("facility_vent_louver", BuildVentMaterial);
        public static Material HighVoltage => Get("facility_high_voltage", BuildHighVoltageMaterial);
        public static Material Whiteboard => Get("facility_whiteboard", BuildWhiteboardMaterial);
        public static Material ExitSign => Get("facility_exit_sign", BuildExitSignMaterial);
        public static Material EpoxyResin => Get("facility_epoxy_resin", () => BuildFlatMaterial(new Color(0.08f, 0.09f, 0.10f), 0.82f, 0.15f));
        public static Material ChemicalGlass => Get("facility_chem_glass", () => BuildFlatMaterial(new Color(0.20f, 0.45f, 0.40f), 0.92f, 0.3f));

        // --- Material Builders -----------------------------------------------

        static Material BuildWallMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var normal = new Texture2D(size, size, TextureFormat.RGBA32, true, true);
            var metallicGloss = new Texture2D(size, size, TextureFormat.RGBA32, true, true);

            var albPixels = new Color32[size * size];
            var metPixels = new Color32[size * size];
            float[,] height = new float[size, size];

            Color baseColorTop = new Color(0.38f, 0.40f, 0.38f);
            Color baseColorBottom = new Color(0.24f, 0.26f, 0.25f);

            for (int y = 0; y < size; y++)
            {
                float verticalGradient = (float)y / size;
                for (int x = 0; x < size; x++)
                {
                    float noise = Mathf.PerlinNoise(x * 0.08f, y * 0.08f) * 0.6f +
                                  Mathf.PerlinNoise(x * 0.35f, y * 0.35f) * 0.4f;

                    // Wall seam line halfway up
                    float seamDist = Mathf.Abs(y - size / 2) / (float)size;
                    float seam = seamDist < 0.015f ? 0.35f : 1.0f;

                    // Vertical grime streaks
                    float streak = Mathf.Clamp01(Mathf.PerlinNoise(x * 0.04f, y * 0.01f) * 1.3f);
                    Color col = Color.Lerp(baseColorBottom, baseColorTop, verticalGradient * 0.8f + 0.2f);
                    col *= (0.8f + noise * 0.35f) * seam * (0.85f + streak * 0.2f);

                    height[x, y] = noise * 0.6f + (seamDist < 0.015f ? -0.4f : 0f);

                    int idx = y * size + x;
                    albPixels[idx] = (Color32)col;
                    // Wall has 0 metallic, smoothness around 0.18-0.35
                    metPixels[idx] = new Color32(0, 0, 0, (byte)(Mathf.Clamp01(0.18f + noise * 0.15f) * 255f));
                }
            }

            ApplyTextures(albedo, albPixels, normal, height, metallicGloss, metPixels);

            var mat = new Material(StandardShader);
            mat.name = "Proc_FacilityWall";
            mat.mainTexture = albedo;
            mat.mainTextureScale = new Vector2(3f, 3f);
            mat.EnableKeyword("_NORMALMAP");
            mat.SetTexture("_BumpMap", normal);
            mat.SetFloat("_BumpScale", 0.9f);
            mat.EnableKeyword("_METALLICGLOSSMAP");
            mat.SetTexture("_MetallicGlossMap", metallicGloss);
            return mat;
        }

        static Material BuildTileFloorMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var normal = new Texture2D(size, size, TextureFormat.RGBA32, true, true);
            var metallicGloss = new Texture2D(size, size, TextureFormat.RGBA32, true, true);

            var albPixels = new Color32[size * size];
            var metPixels = new Color32[size * size];
            float[,] height = new float[size, size];

            int tileSize = size / 4; // 4x4 tiles per texture repeat

            for (int y = 0; y < size; y++)
            {
                int ty = y % tileSize;
                bool isGroutY = ty <= 2 || ty >= tileSize - 2;

                for (int x = 0; x < size; x++)
                {
                    int tx = x % tileSize;
                    bool isGroutX = tx <= 2 || tx >= tileSize - 2;
                    bool isGrout = isGroutX || isGroutY;

                    int tileCoordX = x / tileSize;
                    int tileCoordY = y / tileSize;
                    float tileHash = (float)((tileCoordX * 37 + tileCoordY * 91) % 17) / 17f;

                    float fineNoise = Mathf.PerlinNoise(x * 0.2f, y * 0.2f);
                    float wetNoise = Mathf.PerlinNoise(x * 0.05f + 10f, y * 0.05f + 10f);

                    Color tileColor = Color.Lerp(new Color(0.22f, 0.22f, 0.23f), new Color(0.28f, 0.27f, 0.25f), tileHash);
                    if (isGrout)
                    {
                        tileColor = new Color(0.08f, 0.08f, 0.09f);
                        height[x, y] = -0.6f;
                    }
                    else
                    {
                        tileColor *= (0.85f + fineNoise * 0.3f);
                        height[x, y] = fineNoise * 0.15f;
                    }

                    int idx = y * size + x;
                    albPixels[idx] = (Color32)tileColor;

                    // Floor tiles have high specular smoothness on wet patches (up to 0.75), low on grout
                    float smoothness = isGrout ? 0.1f : Mathf.Lerp(0.35f, 0.72f, wetNoise * wetNoise);
                    metPixels[idx] = new Color32(0, 0, 0, (byte)(smoothness * 255f));
                }
            }

            ApplyTextures(albedo, albPixels, normal, height, metallicGloss, metPixels);

            var mat = new Material(StandardShader);
            mat.name = "Proc_TileFloor";
            mat.mainTexture = albedo;
            mat.mainTextureScale = new Vector2(4f, 4f);
            mat.EnableKeyword("_NORMALMAP");
            mat.SetTexture("_BumpMap", normal);
            mat.SetFloat("_BumpScale", 1.2f);
            mat.EnableKeyword("_METALLICGLOSSMAP");
            mat.SetTexture("_MetallicGlossMap", metallicGloss);
            return mat;
        }

        static Material BuildCeilingGridMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var normal = new Texture2D(size, size, TextureFormat.RGBA32, true, true);
            var metallicGloss = new Texture2D(size, size, TextureFormat.RGBA32, true, true);

            var albPixels = new Color32[size * size];
            var metPixels = new Color32[size * size];
            float[,] height = new float[size, size];

            int tileSize = size / 2; // 2x2 large ceiling panels

            for (int y = 0; y < size; y++)
            {
                int ty = y % tileSize;
                bool isBarY = ty <= 3 || ty >= tileSize - 3;

                for (int x = 0; x < size; x++)
                {
                    int tx = x % tileSize;
                    bool isBarX = tx <= 3 || tx >= tileSize - 3;
                    bool isBar = isBarX || isBarY;

                    float pockmark = Mathf.PerlinNoise(x * 0.8f, y * 0.8f);
                    float stain = Mathf.PerlinNoise(x * 0.04f, y * 0.04f);

                    Color col = isBar
                        ? new Color(0.20f, 0.20f, 0.22f) // Metal T-bar
                        : Color.Lerp(new Color(0.28f, 0.28f, 0.26f), new Color(0.18f, 0.16f, 0.12f), stain * 0.6f);

                    if (!isBar) col *= (0.9f + pockmark * 0.2f);
                    height[x, y] = isBar ? 0.3f : -pockmark * 0.2f;

                    int idx = y * size + x;
                    albPixels[idx] = (Color32)col;
                    byte metallic = isBar ? (byte)180 : (byte)0;
                    byte smoothness = isBar ? (byte)120 : (byte)45;
                    metPixels[idx] = new Color32(metallic, 0, 0, smoothness);
                }
            }

            ApplyTextures(albedo, albPixels, normal, height, metallicGloss, metPixels);

            var mat = new Material(StandardShader);
            mat.name = "Proc_CeilingGrid";
            mat.mainTexture = albedo;
            mat.mainTextureScale = new Vector2(4f, 4f);
            mat.EnableKeyword("_NORMALMAP");
            mat.SetTexture("_BumpMap", normal);
            mat.SetFloat("_BumpScale", 0.9f);
            mat.EnableKeyword("_METALLICGLOSSMAP");
            mat.SetTexture("_MetallicGlossMap", metallicGloss);
            return mat;
        }

        static Material BuildPaintedMetalMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var normal = new Texture2D(size, size, TextureFormat.RGBA32, true, true);
            var metallicGloss = new Texture2D(size, size, TextureFormat.RGBA32, true, true);

            var albPixels = new Color32[size * size];
            var metPixels = new Color32[size * size];
            float[,] height = new float[size, size];

            Color paintColor = new Color(0.25f, 0.32f, 0.30f); // Institutional olive/sage drab
            Color rustColor = new Color(0.38f, 0.19f, 0.10f);  // Iron rust oxide

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float rustNoise = Mathf.PerlinNoise(x * 0.08f, y * 0.08f);
                    float microScratch = Mathf.PerlinNoise(x * 0.7f, y * 0.7f);
                    bool isRust = rustNoise > 0.62f;

                    Color col = isRust
                        ? Color.Lerp(rustColor, rustColor * 0.7f, microScratch)
                        : Color.Lerp(paintColor, paintColor * 0.85f, microScratch);

                    height[x, y] = isRust ? -0.3f - microScratch * 0.3f : 0.1f;

                    int idx = y * size + x;
                    albPixels[idx] = (Color32)col;
                    byte metallic = isRust ? (byte)30 : (byte)190;
                    byte smoothness = isRust ? (byte)35 : (byte)145;
                    metPixels[idx] = new Color32(metallic, 0, 0, smoothness);
                }
            }

            ApplyTextures(albedo, albPixels, normal, height, metallicGloss, metPixels);

            var mat = new Material(StandardShader);
            mat.name = "Proc_PaintedMetal";
            mat.mainTexture = albedo;
            mat.EnableKeyword("_NORMALMAP");
            mat.SetTexture("_BumpMap", normal);
            mat.SetFloat("_BumpScale", 1.1f);
            mat.EnableKeyword("_METALLICGLOSSMAP");
            mat.SetTexture("_MetallicGlossMap", metallicGloss);
            return mat;
        }

        static Material BuildWoodMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var normal = new Texture2D(size, size, TextureFormat.RGBA32, true, true);
            var albPixels = new Color32[size * size];
            float[,] height = new float[size, size];

            Color darkStain = new Color(0.28f, 0.17f, 0.10f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    // Stretched grain along X
                    float grain = Mathf.PerlinNoise(x * 0.03f, y * 0.4f);
                    Color col = darkStain * (0.8f + grain * 0.4f);
                    height[x, y] = grain * 0.25f;
                    albPixels[y * size + x] = (Color32)col;
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);
            GenerateNormalMap(normal, height, 1.0f);

            var mat = new Material(StandardShader);
            mat.name = "Proc_DarkWood";
            mat.mainTexture = albedo;
            mat.EnableKeyword("_NORMALMAP");
            mat.SetTexture("_BumpMap", normal);
            mat.SetFloat("_Glossiness", 0.42f);
            mat.SetFloat("_Metallic", 0.0f);
            return mat;
        }

        static Material BuildPaperMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var albPixels = new Color32[size * size];

            Color paperBase = new Color(0.82f, 0.79f, 0.70f); // Aged yellowed paper
            Color textLine = new Color(0.25f, 0.24f, 0.23f);

            for (int y = 0; y < size; y++)
            {
                bool isTextRow = (y % 16) >= 5 && (y % 16) <= 8;
                for (int x = 0; x < size; x++)
                {
                    bool inMargin = x < 30 || x > size - 30;
                    float blotch = Mathf.PerlinNoise(x * 0.05f, y * 0.05f);
                    Color c = paperBase * (0.92f + blotch * 0.15f);

                    if (isTextRow && !inMargin && (x % 7 != 0))
                    {
                        c = Color.Lerp(c, textLine, 0.75f);
                    }
                    albPixels[y * size + x] = (Color32)c;
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);

            var mat = new Material(StandardShader);
            mat.name = "Proc_Paper";
            mat.mainTexture = albedo;
            mat.SetFloat("_Glossiness", 0.15f);
            mat.SetFloat("_Metallic", 0.0f);
            return mat;
        }

        static Material BuildHazardMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var albPixels = new Color32[size * size];

            Color yellow = new Color(0.92f, 0.75f, 0.10f);
            Color black = new Color(0.12f, 0.12f, 0.12f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    int diagonal = (x + y) / 24;
                    bool isStripe = diagonal % 2 == 0;
                    float grime = Mathf.PerlinNoise(x * 0.1f, y * 0.1f) * 0.25f;
                    Color c = (isStripe ? yellow : black) * (0.85f + grime);
                    albPixels[y * size + x] = (Color32)c;
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);

            var mat = new Material(StandardShader);
            mat.name = "Proc_Hazard";
            mat.mainTexture = albedo;
            mat.SetFloat("_Glossiness", 0.35f);
            mat.SetFloat("_Metallic", 0.1f);
            return mat;
        }

        static Material BuildBiohazardMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var albPixels = new Color32[size * size];

            Color white = new Color(0.85f, 0.85f, 0.82f);
            Color redAlert = new Color(0.78f, 0.15f, 0.12f);
            Vector2 center = new Vector2(size * 0.5f, size * 0.5f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dist = Vector2.Distance(new Vector2(x, y), center);
                    bool isBorder = x < 12 || x > size - 12 || y < 12 || y > size - 12;
                    bool isCenterSymbol = dist > 35 && dist < 58;

                    Color c = (isBorder || isCenterSymbol) ? redAlert : white;
                    albPixels[y * size + x] = (Color32)c;
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);

            var mat = new Material(StandardShader);
            mat.name = "Proc_Biohazard";
            mat.mainTexture = albedo;
            mat.SetFloat("_Glossiness", 0.3f);
            mat.SetFloat("_Metallic", 0.05f);
            return mat;
        }

        static Material BuildCardboardMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var albPixels = new Color32[size * size];
            Color kraft = new Color(0.52f, 0.38f, 0.22f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float noise = Mathf.PerlinNoise(x * 0.25f, y * 0.25f);
                    albPixels[y * size + x] = (Color32)(kraft * (0.85f + noise * 0.3f));
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);

            var mat = new Material(StandardShader);
            mat.name = "Proc_Cardboard";
            mat.mainTexture = albedo;
            mat.SetFloat("_Glossiness", 0.12f);
            mat.SetFloat("_Metallic", 0.0f);
            return mat;
        }

        static Material BuildPipeMaterial()
        {
            var mat = new Material(StandardShader);
            mat.name = "Proc_Pipe";
            mat.color = new Color(0.38f, 0.40f, 0.42f);
            mat.SetFloat("_Glossiness", 0.65f);
            mat.SetFloat("_Metallic", 0.85f);
            return mat;
        }

        static Material BuildMattressMaterial()
        {
            var mat = new Material(StandardShader);
            mat.name = "Proc_Mattress";
            mat.color = new Color(0.28f, 0.35f, 0.32f); // Disinfected hospital cyan-green vinyl
            mat.SetFloat("_Glossiness", 0.48f);
            mat.SetFloat("_Metallic", 0.05f);
            return mat;
        }

        static Material BuildBloodMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGBA32, true);
            var normal = new Texture2D(size, size, TextureFormat.RGBA32, true, true);
            var albPixels = new Color32[size * size];
            float[,] height = new float[size, size];

            Color darkBlood = new Color(0.32f, 0.04f, 0.03f, 0.95f);
            Color dryEdge = new Color(0.18f, 0.02f, 0.02f, 0.7f);
            Vector2 center = new Vector2(size * 0.5f, size * 0.5f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dist = Vector2.Distance(new Vector2(x, y), center) / (size * 0.45f);
                    float spatterNoise = Mathf.PerlinNoise(x * 0.12f, y * 0.12f) * 0.5f +
                                         Mathf.PerlinNoise(x * 0.4f, y * 0.4f) * 0.5f;

                    float pool = Mathf.Clamp01((1.0f - dist) + (spatterNoise - 0.4f) * 1.5f);
                    bool hasBlood = pool > 0.45f;

                    Color col = hasBlood ? Color.Lerp(dryEdge, darkBlood, pool) : new Color(0f, 0f, 0f, 0f);
                    albPixels[y * size + x] = (Color32)col;
                    height[x, y] = hasBlood ? 0.3f * pool : 0f;
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);
            GenerateNormalMap(normal, height, 1.5f);

            var mat = new Material(StandardShader);
            mat.name = "Proc_BloodStain";
            mat.mainTexture = albedo;
            mat.EnableKeyword("_NORMALMAP");
            mat.SetTexture("_BumpMap", normal);
            mat.SetFloat("_Glossiness", 0.85f); // Wet specular gleam
            mat.SetFloat("_Metallic", 0.05f);
            return mat;
        }

        static Material BuildVentMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var normal = new Texture2D(size, size, TextureFormat.RGBA32, true, true);
            var albPixels = new Color32[size * size];
            float[,] height = new float[size, size];

            Color metalRim = new Color(0.24f, 0.25f, 0.26f);
            Color darkSlot = new Color(0.04f, 0.04f, 0.05f);

            for (int y = 0; y < size; y++)
            {
                bool isRimY = y < 16 || y > size - 16;
                bool isLouver = (y % 16) < 6;
                for (int x = 0; x < size; x++)
                {
                    bool isRimX = x < 16 || x > size - 16;
                    bool isRim = isRimX || isRimY;

                    Color c = isRim ? metalRim : (isLouver ? darkSlot : metalRim * 0.75f);
                    albPixels[y * size + x] = (Color32)c;
                    height[x, y] = isRim ? 0.3f : (isLouver ? -0.5f : 0.1f);
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);
            GenerateNormalMap(normal, height, 2.0f);

            var mat = new Material(StandardShader);
            mat.name = "Proc_VentLouver";
            mat.mainTexture = albedo;
            mat.EnableKeyword("_NORMALMAP");
            mat.SetTexture("_BumpMap", normal);
            mat.SetFloat("_Glossiness", 0.55f);
            mat.SetFloat("_Metallic", 0.75f);
            return mat;
        }

        static Material BuildHighVoltageMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var albPixels = new Color32[size * size];

            Color yellow = new Color(0.95f, 0.76f, 0.08f);
            Color black = new Color(0.10f, 0.10f, 0.10f);

            for (int y = 0; y < size; y++)
            {
                bool isBorder = y < 14 || y > size - 14;
                for (int x = 0; x < size; x++)
                {
                    bool isBorderX = x < 14 || x > size - 14;
                    // Lightning bolt diagonal slash
                    int bolt = (x * 2 - y);
                    bool isSymbol = (bolt > 100 && bolt < 155 && y > 50 && y < 200) ||
                                    (x > 115 && x < 140 && y > 120 && y < 160);

                    Color c = (isBorder || isBorderX || isSymbol) ? black : yellow;
                    albPixels[y * size + x] = (Color32)c;
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);

            var mat = new Material(StandardShader);
            mat.name = "Proc_HighVoltage";
            mat.mainTexture = albedo;
            mat.SetFloat("_Glossiness", 0.4f);
            mat.SetFloat("_Metallic", 0.1f);
            return mat;
        }

        static Material BuildWhiteboardMaterial()
        {
            const int size = 256;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var albPixels = new Color32[size * size];

            Color board = new Color(0.92f, 0.93f, 0.94f);
            Color markerBlue = new Color(0.12f, 0.25f, 0.65f);
            Color markerRed = new Color(0.75f, 0.15f, 0.15f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    Color c = board;
                    // Scribbled graph lines
                    float graphY = 128f + Mathf.Sin(x * 0.08f) * 45f;
                    if (Mathf.Abs(y - graphY) < 3.5f) c = markerBlue;

                    // Vital spike
                    if (x > 180 && x < 210 && Mathf.Abs(y - (130f + (x - 180) * 3f)) < 3f) c = markerRed;

                    albPixels[y * size + x] = (Color32)c;
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);

            var mat = new Material(StandardShader);
            mat.name = "Proc_Whiteboard";
            mat.mainTexture = albedo;
            mat.SetFloat("_Glossiness", 0.88f); // Glossy dry-erase surface
            mat.SetFloat("_Metallic", 0.05f);
            return mat;
        }

        static Material BuildExitSignMaterial()
        {
            const int size = 128;
            var albedo = new Texture2D(size, size, TextureFormat.RGB24, true);
            var albPixels = new Color32[size * size];

            Color greenGlow = new Color(0.15f, 0.92f, 0.35f);
            Color darkGreen = new Color(0.04f, 0.22f, 0.08f);

            for (int y = 0; y < size; y++)
            {
                bool isBorder = y < 8 || y > size - 8;
                for (int x = 0; x < size; x++)
                {
                    bool isBorderX = x < 8 || x > size - 8;
                    bool inTextRegion = y > 40 && y < 88 && x > 20 && x < size - 20;

                    Color c = (isBorder || isBorderX || inTextRegion) ? greenGlow : darkGreen;
                    albPixels[y * size + x] = (Color32)c;
                }
            }

            albedo.SetPixels32(albPixels);
            albedo.Apply(true);

            var mat = new Material(StandardShader);
            mat.name = "Proc_ExitSign";
            mat.mainTexture = albedo;
            mat.EnableKeyword("_EMISSION");
            mat.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
            mat.SetColor("_EmissionColor", greenGlow * 1.8f);
            mat.SetTexture("_EmissionMap", albedo);
            mat.SetFloat("_Glossiness", 0.6f);
            return mat;
        }

        static Material BuildFlatMaterial(Color color, float smoothness, float metallic)
        {
            var mat = new Material(StandardShader);
            mat.color = color;
            mat.SetFloat("_Glossiness", smoothness);
            mat.SetFloat("_Metallic", metallic);
            return mat;
        }

        // --- Texture Utilities -----------------------------------------------

        static void ApplyTextures(Texture2D albedo, Color32[] albPixels, Texture2D normal, float[,] height, Texture2D metGloss, Color32[] metPixels)
        {
            albedo.SetPixels32(albPixels);
            albedo.Apply(true);

            metGloss.SetPixels32(metPixels);
            metGloss.Apply(true);

            GenerateNormalMap(normal, height, 1.8f);
        }

        /// <summary>
        /// Generates a tangent-space normal map using Sobel filtering with dual DXT5nm & RGB encoding
        /// for 100% universal compatibility across all platforms and shader unpack modes.
        /// </summary>
        static void GenerateNormalMap(Texture2D normalTex, float[,] height, float strength)
        {
            int size = height.GetLength(0);
            var pixels = new Color32[size * size];

            for (int y = 0; y < size; y++)
            {
                int ym1 = (y - 1 + size) % size;
                int yp1 = (y + 1) % size;

                for (int x = 0; x < size; x++)
                {
                    int xm1 = (x - 1 + size) % size;
                    int xp1 = (x + 1) % size;

                    float dx = (height[xp1, y] - height[xm1, y]) * strength;
                    float dy = (height[x, yp1] - height[x, ym1]) * strength;

                    Vector3 n = new Vector3(-dx, -dy, 1.0f).normalized;

                    // Dual encode: R and A both hold X (compatible with both RGB and DXT5nm unpack)
                    byte r = (byte)(Mathf.Clamp01(n.x * 0.5f + 0.5f) * 255f);
                    byte g = (byte)(Mathf.Clamp01(n.y * 0.5f + 0.5f) * 255f);
                    byte b = (byte)(Mathf.Clamp01(n.z * 0.5f + 0.5f) * 255f);
                    byte a = r;

                    pixels[y * size + x] = new Color32(r, g, b, a);
                }
            }

            normalTex.SetPixels32(pixels);
            normalTex.Apply(true);
        }

        static Material Get(string key, System.Func<Material> factory)
        {
            if (Cache.TryGetValue(key, out var existing) && existing != null) return existing;
            var created = factory();
            Cache[key] = created;
            return created;
        }
    }
}
