using Hollowmere.Gen;
using UnityEditor;
using UnityEngine;

namespace Hollowmere.EditorTools
{
    public static class EnvironmentUpgradeTester
    {
        [MenuItem("Hollowmere/Test Full Environment Generation", priority = 42)]
        public static void RunTest()
        {
            try
            {
                int testSeed = 1042;
                int fuseCount = 4;
                var data = LevelGenerator.Generate(testSeed, fuseCount);

                int wallCount = data.Root.Find("Walls")?.childCount ?? 0;
                int archCount = data.Root.Find("ArchitecturalDetails")?.childCount ?? 0;
                int propsCount = data.Root.Find("FacilityProps")?.childCount ?? 0;
                int fixtureCount = data.Root.Find("CeilingFixtures")?.childCount ?? 0;

                Debug.Log($"[Hollowmere] Environment Generation Test PASSED! " +
                          $"Rooms: {data.Rooms.Count}, Walls: {wallCount}, Baseboards/Portals: {archCount}, " +
                          $"Props: {propsCount}, Lights: {fixtureCount}. Static batching combined successfully.");

                // Clean up test game objects so editor scene stays empty
                Object.DestroyImmediate(data.Root.gameObject);
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[Hollowmere] Environment Generation Test FAILED: {ex}");
            }
        }
    }
}
