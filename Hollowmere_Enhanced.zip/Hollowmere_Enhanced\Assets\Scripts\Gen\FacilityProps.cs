using UnityEngine;

namespace Hollowmere.Gen
{
    /// <summary>
    /// Reusable procedural prop library for abandoned facility environments.
    /// Builds compound architectural and decorative assets with authentic proportions,
    /// optimized materials, and clean collision boundaries that respect AI and player movement.
    /// </summary>
    public static class FacilityProps
    {
        // --- Core Primitives Helper ------------------------------------------

        public static GameObject MakePart(Transform parent, string name, Vector3 localPos, Vector3 size, Material material, bool keepCollider = false)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = size;
            go.GetComponent<MeshRenderer>().sharedMaterial = material;

            var col = go.GetComponent<Collider>();
            if (col != null && !keepCollider)
            {
                Object.Destroy(col);
            }
            return go;
        }

        // --- Props -----------------------------------------------------------

        /// <summary>
        /// Heavy institutional office desk with drawers, desk lamp, and paperwork.
        /// Has a solid BoxCollider on root so it provides tactical stealth cover against entity line of sight.
        /// </summary>
        public static GameObject CreateOfficeDesk(Transform parent, Vector3 position, Quaternion rotation, System.Random rng)
        {
            var root = new GameObject("OfficeDesk");
            root.transform.SetParent(parent, false);
            root.transform.position = position;
            root.transform.rotation = rotation;

            const float w = 1.6f, d = 0.85f, h = 0.78f, topThick = 0.045f;

            // Desktop slab (Dark Wood)
            MakePart(root.transform, "Desktop", new Vector3(0f, h - topThick * 0.5f, 0f),
                new Vector3(w, topThick, d), EnhancedMaterials.DarkWood);

            // Modesty panel (Painted Metal)
            MakePart(root.transform, "ModestyPanel", new Vector3(0f, h * 0.55f, d * 0.42f),
                new Vector3(w - 0.1f, h * 0.65f, 0.03f), EnhancedMaterials.PaintedMetal);

            // Left legs (2 square metal legs)
            float legX = -w * 0.5f + 0.06f;
            MakePart(root.transform, "LegFL", new Vector3(legX, (h - topThick) * 0.5f, -d * 0.5f + 0.06f),
                new Vector3(0.06f, h - topThick, 0.06f), EnhancedMaterials.PaintedMetal);
            MakePart(root.transform, "LegBL", new Vector3(legX, (h - topThick) * 0.5f, d * 0.5f - 0.06f),
                new Vector3(0.06f, h - topThick, 0.06f), EnhancedMaterials.PaintedMetal);

            // Right drawer pedestal (3 drawers with chrome handles)
            float pedW = 0.48f, pedH = h - topThick, pedD = d - 0.08f;
            float pedX = w * 0.5f - pedW * 0.5f - 0.04f;
            MakePart(root.transform, "PedestalBody", new Vector3(pedX, pedH * 0.5f, 0f),
                new Vector3(pedW, pedH, pedD), EnhancedMaterials.PaintedMetal);

            for (int i = 0; i < 3; i++)
            {
                float drawerY = 0.12f + i * 0.22f;
                // Drawer face
                MakePart(root.transform, $"Drawer_{i}", new Vector3(pedX, drawerY, -pedD * 0.5f - 0.01f),
                    new Vector3(pedW * 0.92f, 0.18f, 0.02f), EnhancedMaterials.PaintedMetal);
                // Handle
                MakePart(root.transform, $"Handle_{i}", new Vector3(pedX, drawerY, -pedD * 0.5f - 0.025f),
                    new Vector3(0.12f, 0.02f, 0.02f), EnhancedMaterials.Chrome);
            }

            // Clutter on desk:
            // Desk lamp
            var lampGo = new GameObject("DeskLamp");
            lampGo.transform.SetParent(root.transform, false);
            lampGo.transform.localPosition = new Vector3(-w * 0.35f, h, d * 0.25f);
            MakePart(lampGo.transform, "Base", Vector3.zero, new Vector3(0.16f, 0.02f, 0.16f), EnhancedMaterials.PaintedMetal);
            MakePart(lampGo.transform, "Arm", new Vector3(0f, 0.15f, 0f), new Vector3(0.03f, 0.3f, 0.03f), EnhancedMaterials.Chrome);
            MakePart(lampGo.transform, "Hood", new Vector3(0.06f, 0.32f, -0.06f), new Vector3(0.16f, 0.08f, 0.14f), EnhancedMaterials.PaintedMetal);

            var lampLight = lampGo.AddComponent<Light>();
            lampLight.type = LightType.Point;
            lampLight.range = 3.2f;
            lampLight.intensity = 0.75f;
            lampLight.color = new Color(1.0f, 0.88f, 0.65f); // Warm incandescent
            lampLight.shadows = LightShadows.None;

            // Scattered papers on desktop
            int paperCount = rng.Next(2, 4);
            for (int i = 0; i < paperCount; i++)
            {
                float px = (float)(rng.NextDouble() - 0.5) * 0.5f;
                float pz = (float)(rng.NextDouble() - 0.5) * 0.3f;
                float rot = (float)(rng.NextDouble() * 50f - 25f);
                var paper = MakePart(root.transform, "Paper", new Vector3(px, h + 0.005f + i * 0.002f, pz),
                    new Vector3(0.24f, 0.002f, 0.32f), EnhancedMaterials.Paper);
                paper.transform.localRotation = Quaternion.Euler(0f, rot, 0f);
            }

            // Single Root Cover Collider
            var boxCol = root.AddComponent<BoxCollider>();
            boxCol.center = new Vector3(0f, h * 0.5f, 0f);
            boxCol.size = new Vector3(w, h, d);

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Office swivel chair. Padded vinyl seat and curved backrest on caster base.
        /// No collider to prevent snagging player locomotion.
        /// </summary>
        public static GameObject CreateOfficeChair(Transform parent, Vector3 position, Quaternion rotation, bool knockedOver = false)
        {
            var root = new GameObject("OfficeChair");
            root.transform.SetParent(parent, false);
            root.transform.position = position;

            if (knockedOver)
            {
                root.transform.rotation = rotation * Quaternion.Euler(0f, 0f, 85f);
                root.transform.position += Vector3.up * 0.15f;
            }
            else
            {
                root.transform.rotation = rotation;
            }

            // Central stem & base
            MakePart(root.transform, "Base", new Vector3(0f, 0.08f, 0f), new Vector3(0.48f, 0.04f, 0.48f), EnhancedMaterials.PaintedMetal);
            MakePart(root.transform, "Stem", new Vector3(0f, 0.25f, 0f), new Vector3(0.06f, 0.32f, 0.06f), EnhancedMaterials.Chrome);

            // Seat cushion
            MakePart(root.transform, "Seat", new Vector3(0f, 0.45f, 0f), new Vector3(0.46f, 0.08f, 0.46f), EnhancedMaterials.PaintedMetal);

            // Backrest
            MakePart(root.transform, "BackPost", new Vector3(0f, 0.65f, 0.21f), new Vector3(0.05f, 0.35f, 0.03f), EnhancedMaterials.PaintedMetal);
            MakePart(root.transform, "BackCushion", new Vector3(0f, 0.72f, 0.20f), new Vector3(0.42f, 0.30f, 0.07f), EnhancedMaterials.PaintedMetal);

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// 4-Drawer vertical steel filing cabinet.
        /// Has BoxCollider on root for stealth cover.
        /// </summary>
        public static GameObject CreateFilingCabinet(Transform parent, Vector3 position, Quaternion rotation, bool openDrawer = false)
        {
            var root = new GameObject("FilingCabinet");
            root.transform.SetParent(parent, false);
            root.transform.position = position;
            root.transform.rotation = rotation;

            const float w = 0.52f, d = 0.65f, h = 1.35f;

            // Main steel shell
            MakePart(root.transform, "Shell", new Vector3(0f, h * 0.5f, 0f),
                new Vector3(w, h, d), EnhancedMaterials.PaintedMetal);

            // 4 Drawer fronts with handles
            float drawerH = (h - 0.1f) / 4f;
            for (int i = 0; i < 4; i++)
            {
                float dy = 0.06f + i * drawerH + drawerH * 0.5f;
                bool isAjar = openDrawer && i == 2;
                float pushOut = isAjar ? -0.22f : 0f;

                var drawer = MakePart(root.transform, $"Drawer_{i}",
                    new Vector3(0f, dy, -d * 0.5f - 0.01f + pushOut),
                    new Vector3(w * 0.90f, drawerH * 0.90f, isAjar ? 0.35f : 0.02f), EnhancedMaterials.PaintedMetal);

                // Chrome handle
                MakePart(drawer.transform, "Handle", new Vector3(0f, 0.02f, -0.025f),
                    new Vector3(0.12f, 0.025f, 0.02f), EnhancedMaterials.Chrome);

                // Label card
                MakePart(drawer.transform, "LabelCard", new Vector3(0f, 0.07f, -0.015f),
                    new Vector3(0.09f, 0.04f, 0.005f), EnhancedMaterials.Paper);

                if (isAjar)
                {
                    // Files inside open drawer
                    MakePart(drawer.transform, "Files", new Vector3(0f, 0.03f, 0.08f),
                        new Vector3(w * 0.75f, drawerH * 0.6f, 0.20f), EnhancedMaterials.Cardboard);
                }
            }

            var col = root.AddComponent<BoxCollider>();
            col.center = new Vector3(0f, h * 0.5f, 0f);
            col.size = new Vector3(w, h, d + (openDrawer ? 0.22f : 0f));

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Slotted angle-iron industrial shelving unit with archive boxes and chemical canisters.
        /// Has BoxCollider on root for stealth cover.
        /// </summary>
        public static GameObject CreateIndustrialShelving(Transform parent, Vector3 position, Quaternion rotation, System.Random rng)
        {
            var root = new GameObject("IndustrialShelving");
            root.transform.SetParent(parent, false);
            root.transform.position = position;
            root.transform.rotation = rotation;

            const float w = 1.4f, d = 0.55f, h = 1.95f;
            const int shelfCount = 4;

            // 4 Corner upright posts
            float px = w * 0.5f - 0.03f;
            float pz = d * 0.5f - 0.03f;
            MakePart(root.transform, "Post_FL", new Vector3(-px, h * 0.5f, -pz), new Vector3(0.04f, h, 0.04f), EnhancedMaterials.PaintedMetal);
            MakePart(root.transform, "Post_FR", new Vector3(px, h * 0.5f, -pz), new Vector3(0.04f, h, 0.04f), EnhancedMaterials.PaintedMetal);
            MakePart(root.transform, "Post_BL", new Vector3(-px, h * 0.5f, pz), new Vector3(0.04f, h, 0.04f), EnhancedMaterials.PaintedMetal);
            MakePart(root.transform, "Post_BR", new Vector3(px, h * 0.5f, pz), new Vector3(0.04f, h, 0.04f), EnhancedMaterials.PaintedMetal);

            // Horizontal shelves & contents
            for (int i = 0; i < shelfCount; i++)
            {
                float sy = 0.12f + i * (h / (shelfCount - 0.2f));
                MakePart(root.transform, $"Shelf_{i}", new Vector3(0f, sy, 0f),
                    new Vector3(w, 0.03f, d), EnhancedMaterials.PaintedMetal);

                if (i < shelfCount - 1)
                {
                    // Add 1-2 cardboard boxes or canisters
                    int items = rng.Next(1, 3);
                    for (int k = 0; k < items; k++)
                    {
                        float ix = (k == 0 ? -1f : 1f) * (0.28f + (float)rng.NextDouble() * 0.15f);
                        if (rng.NextDouble() > 0.35)
                        {
                            // Cardboard box
                            float boxH = 0.26f + (float)rng.NextDouble() * 0.08f;
                            MakePart(root.transform, $"Box_{i}_{k}", new Vector3(ix, sy + boxH * 0.5f + 0.015f, 0f),
                                new Vector3(0.36f, boxH, 0.38f), EnhancedMaterials.Cardboard);
                        }
                        else
                        {
                            // Metal canister
                            MakePart(root.transform, $"Canister_{i}_{k}", new Vector3(ix, sy + 0.15f, 0f),
                                new Vector3(0.20f, 0.30f, 0.20f), EnhancedMaterials.PipeMetal);
                        }
                    }
                }
            }

            var col = root.AddComponent<BoxCollider>();
            col.center = new Vector3(0f, h * 0.5f, 0f);
            col.size = new Vector3(w, h, d);

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Wheeled hospital / facility examination cot with vinyl mattress and raised headrest.
        /// Has BoxCollider on root for stealth cover.
        /// </summary>
        public static GameObject CreateMedicalCot(Transform parent, Vector3 position, Quaternion rotation)
        {
            var root = new GameObject("MedicalCot");
            root.transform.SetParent(parent, false);
            root.transform.position = position;
            root.transform.rotation = rotation;

            const float w = 0.9f, length = 2.05f, frameH = 0.55f;

            // Metal frame legs with casters
            MakePart(root.transform, "Leg_FL", new Vector3(-w * 0.45f, frameH * 0.5f, -length * 0.45f), new Vector3(0.05f, frameH, 0.05f), EnhancedMaterials.Chrome);
            MakePart(root.transform, "Leg_FR", new Vector3(w * 0.45f, frameH * 0.5f, -length * 0.45f), new Vector3(0.05f, frameH, 0.05f), EnhancedMaterials.Chrome);
            MakePart(root.transform, "Leg_BL", new Vector3(-w * 0.45f, frameH * 0.5f, length * 0.45f), new Vector3(0.05f, frameH, 0.05f), EnhancedMaterials.Chrome);
            MakePart(root.transform, "Leg_BR", new Vector3(w * 0.45f, frameH * 0.5f, length * 0.45f), new Vector3(0.05f, frameH, 0.05f), EnhancedMaterials.Chrome);

            // Frame perimeter rails
            MakePart(root.transform, "BedBase", new Vector3(0f, frameH, 0f), new Vector3(w, 0.05f, length), EnhancedMaterials.PaintedMetal);

            // Mattress main body
            float matThick = 0.12f;
            MakePart(root.transform, "MattressBody", new Vector3(0f, frameH + matThick * 0.5f + 0.02f, -length * 0.12f),
                new Vector3(w * 0.94f, matThick, length * 0.72f), EnhancedMaterials.Mattress);

            // Incline headrest section
            var headrest = MakePart(root.transform, "Headrest",
                new Vector3(0f, frameH + matThick * 0.75f + 0.02f, length * 0.36f),
                new Vector3(w * 0.94f, matThick, length * 0.28f), EnhancedMaterials.Mattress);
            headrest.transform.localRotation = Quaternion.Euler(-18f, 0f, 0f);

            // IV Drip stand attachment
            var ivPole = MakePart(root.transform, "IVPole",
                new Vector3(-w * 0.52f, 0.95f, length * 0.45f), new Vector3(0.03f, 1.8f, 0.03f), EnhancedMaterials.Chrome);
            MakePart(ivPole.transform, "IVArm", new Vector3(0.12f, 0.85f, 0f), new Vector3(0.25f, 0.02f, 0.02f), EnhancedMaterials.Chrome);
            MakePart(ivPole.transform, "IVBottle", new Vector3(0.20f, 0.75f, 0f), new Vector3(0.08f, 0.18f, 0.08f), EnhancedMaterials.Chrome);

            var col = root.AddComponent<BoxCollider>();
            col.center = new Vector3(0f, frameH * 0.75f, 0f);
            col.size = new Vector3(w, frameH * 1.5f, length);

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Suspended 2-tube industrial fluorescent fixture with metal casing and cool light.
        /// No collider (ceiling mounted).
        /// </summary>
        public static GameObject CreateFluorescentFixture(Transform parent, Vector3 position, Quaternion rotation, bool flicker = false, System.Random rng = null)
        {
            var root = new GameObject("FluorescentFixture");
            root.transform.SetParent(parent, false);
            root.transform.position = position;
            root.transform.rotation = rotation;

            const float len = 1.35f, width = 0.38f, thick = 0.09f;

            // Sheet metal casing
            MakePart(root.transform, "Housing", new Vector3(0f, -thick * 0.5f, 0f),
                new Vector3(width, thick, len), EnhancedMaterials.PaintedMetal);

            // 2 Glowing fluorescent tubes
            var tubeEmissive = ProceduralMaterials.Emissive(new Color(0.92f, 0.98f, 0.96f), 2.4f);
            MakePart(root.transform, "Tube_L", new Vector3(-width * 0.25f, -thick - 0.02f, 0f),
                new Vector3(0.045f, 0.045f, len * 0.92f), tubeEmissive);
            MakePart(root.transform, "Tube_R", new Vector3(width * 0.25f, -thick - 0.02f, 0f),
                new Vector3(0.045f, 0.045f, len * 0.92f), tubeEmissive);

            // Point light
            var lightGo = new GameObject("LightSource");
            lightGo.transform.SetParent(root.transform, false);
            lightGo.transform.localPosition = new Vector3(0f, -thick - 0.15f, 0f);

            var light = lightGo.AddComponent<Light>();
            light.type = LightType.Point;
            light.range = 9.5f;
            light.intensity = 0.95f;
            light.color = new Color(0.85f, 0.92f, 0.90f); // Cool hospital fluorescent
            light.shadows = LightShadows.Soft;
            light.shadowStrength = 0.85f;

            if (flicker && rng != null)
            {
                var fl = lightGo.AddComponent<FlickerLight>();
                fl.Configure(0.95f, (float)rng.NextDouble() * 10f, rng.NextDouble() > 0.6);
            }

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Overhead industrial pipe / conduit run with joint flange rings.
        /// No collider (overhead).
        /// </summary>
        public static GameObject CreateOverheadPipe(Transform parent, Vector3 start, Vector3 end, float diameter = 0.08f)
        {
            var root = new GameObject("OverheadPipe");
            root.transform.SetParent(parent, false);

            Vector3 delta = end - start;
            float length = delta.magnitude;
            if (length < 0.1f) return root;

            root.transform.position = start + delta * 0.5f;
            root.transform.rotation = Quaternion.LookRotation(delta.normalized);

            // Main pipe segment
            MakePart(root.transform, "PipeBody", Vector3.zero,
                new Vector3(diameter, diameter, length), EnhancedMaterials.PipeMetal);

            // Flange joint rings every 2m
            int flanges = Mathf.Max(1, Mathf.FloorToInt(length / 2.0f));
            for (int i = 0; i <= flanges; i++)
            {
                float z = -length * 0.5f + i * (length / Mathf.Max(1, flanges));
                MakePart(root.transform, $"Flange_{i}", new Vector3(0f, 0f, z),
                    new Vector3(diameter * 1.5f, diameter * 1.5f, 0.04f), EnhancedMaterials.PaintedMetal);
            }

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Framed wall plaque (evacuation diagram, quarantine notice, biohazard placard).
        /// Sits flush on the wall. No collider.
        /// </summary>
        public static GameObject CreateWallPlaque(Transform parent, Vector3 wallPos, Quaternion wallRot, Material noticeMat, Vector2 size)
        {
            var root = new GameObject("WallPlaque");
            root.transform.SetParent(parent, false);
            root.transform.position = wallPos;
            root.transform.rotation = wallRot;

            // Frame molding
            MakePart(root.transform, "Frame", Vector3.zero,
                new Vector3(size.x + 0.06f, size.y + 0.06f, 0.02f), EnhancedMaterials.PaintedMetal);

            // Notice face
            MakePart(root.transform, "Face", new Vector3(0f, 0f, -0.012f),
                new Vector3(size.x, size.y, 0.005f), noticeMat);

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Scattered loose paper documents on the floor. No collider.
        /// </summary>
        public static void CreateFloorDebris(Transform parent, Vector3 center, System.Random rng)
        {
            int count = rng.Next(2, 5);
            for (int i = 0; i < count; i++)
            {
                Vector3 pos = center + new Vector3(
                    (float)(rng.NextDouble() - 0.5) * 1.8f,
                    0.005f + i * 0.002f,
                    (float)(rng.NextDouble() - 0.5) * 1.8f);

                float rot = (float)(rng.NextDouble() * 360f);
                var paper = MakePart(parent, "FloorPaper", pos,
                    new Vector3(0.24f, 0.002f, 0.32f), EnhancedMaterials.Paper);
                paper.transform.rotation = Quaternion.Euler(0f, rot, 0f);
                paper.isStatic = true;
            }
        }

        /// <summary>
        /// Beveled metal doorway portal frame and lintel for corridor-room transitions.
        /// </summary>
        public static GameObject CreateDoorwayFrame(Transform parent, Vector3 center, Quaternion rotation)
        {
            var root = new GameObject("DoorwayFrame");
            root.transform.SetParent(parent, false);
            root.transform.position = center;
            root.transform.rotation = rotation;

            const float w = 2.85f, h = 3.35f, jambThick = 0.16f, depth = 0.35f;

            // Left jamb
            MakePart(root.transform, "Jamb_L", new Vector3(-w * 0.5f + jambThick * 0.5f, h * 0.5f, 0f),
                new Vector3(jambThick, h, depth), EnhancedMaterials.PaintedMetal);

            // Right jamb
            MakePart(root.transform, "Jamb_R", new Vector3(w * 0.5f - jambThick * 0.5f, h * 0.5f, 0f),
                new Vector3(jambThick, h, depth), EnhancedMaterials.PaintedMetal);

            // Header lintel
            MakePart(root.transform, "Lintel", new Vector3(0f, h - jambThick * 0.5f, 0f),
                new Vector3(w, jambThick, depth), EnhancedMaterials.PaintedMetal);

            // Hazard stripe plate across top lintel
            MakePart(root.transform, "CautionPlate", new Vector3(0f, h - jambThick * 0.5f, -depth * 0.5f - 0.01f),
                new Vector3(w * 0.8f, 0.08f, 0.01f), EnhancedMaterials.HazardStripe);

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Wall-mounted research whiteboard with aluminum trim and marker tray.
        /// </summary>
        public static GameObject CreateWhiteboard(Transform parent, Vector3 wallPos, Quaternion wallRot, Vector2 size)
        {
            var root = new GameObject("Whiteboard");
            root.transform.SetParent(parent, false);
            root.transform.position = wallPos;
            root.transform.rotation = wallRot;

            // Aluminum perimeter frame
            MakePart(root.transform, "Frame", Vector3.zero,
                new Vector3(size.x + 0.06f, size.y + 0.06f, 0.02f), EnhancedMaterials.Chrome);

            // Dry-erase surface
            MakePart(root.transform, "BoardFace", new Vector3(0f, 0f, -0.012f),
                new Vector3(size.x, size.y, 0.005f), EnhancedMaterials.Whiteboard);

            // Marker tray at bottom
            MakePart(root.transform, "Tray", new Vector3(0f, -size.y * 0.5f - 0.015f, -0.035f),
                new Vector3(size.x * 0.85f, 0.02f, 0.05f), EnhancedMaterials.PaintedMetal);

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Laboratory research workbench with black epoxy resin surface, lower storage, and reagent glassware.
        /// Has BoxCollider on root for stealth cover.
        /// </summary>
        public static GameObject CreateLabCounter(Transform parent, Vector3 position, Quaternion rotation, System.Random rng)
        {
            var root = new GameObject("LabCounter");
            root.transform.SetParent(parent, false);
            root.transform.position = position;
            root.transform.rotation = rotation;

            const float w = 2.2f, d = 0.85f, h = 0.88f;

            // Base storage cabinet (Painted Metal)
            MakePart(root.transform, "BaseCabinets", new Vector3(0f, (h - 0.06f) * 0.5f, 0f),
                new Vector3(w - 0.08f, h - 0.06f, d - 0.08f), EnhancedMaterials.PaintedMetal);

            // Epoxy resin worktop (glossy black chemical-resistant)
            MakePart(root.transform, "Worktop", new Vector3(0f, h - 0.03f, 0f),
                new Vector3(w, 0.06f, d), EnhancedMaterials.EpoxyResin);

            // Reagent bottles & glassware
            int bottleCount = rng.Next(2, 5);
            for (int i = 0; i < bottleCount; i++)
            {
                float bx = (float)(rng.NextDouble() - 0.5) * (w * 0.7f);
                float bz = (float)(rng.NextDouble() - 0.5) * (d * 0.5f);
                float bH = 0.16f + (float)rng.NextDouble() * 0.12f;
                MakePart(root.transform, $"Bottle_{i}", new Vector3(bx, h + bH * 0.5f, bz),
                    new Vector3(0.08f, bH, 0.08f), EnhancedMaterials.ChemicalGlass);
            }

            var col = root.AddComponent<BoxCollider>();
            col.center = new Vector3(0f, h * 0.5f, 0f);
            col.size = new Vector3(w, h, d);

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Drooping electrical wires hanging from ceiling / conduits.
        /// </summary>
        public static GameObject CreateHangingWires(Transform parent, Vector3 ceilingPos, float length = 1.1f)
        {
            var root = new GameObject("HangingWires");
            root.transform.SetParent(parent, false);
            root.transform.position = ceilingPos;

            // Junction box
            MakePart(root.transform, "JunctionBox", Vector3.zero,
                new Vector3(0.18f, 0.08f, 0.18f), EnhancedMaterials.PaintedMetal);

            // 2-3 dangling wire segments
            for (int i = 0; i < 3; i++)
            {
                float angle = i * 45f - 45f;
                float wireL = length * (0.6f + (i * 0.2f));
                var wire = MakePart(root.transform, $"Wire_{i}",
                    new Vector3(Mathf.Sin(angle * Mathf.Deg2Rad) * 0.06f, -wireL * 0.5f, Mathf.Cos(angle * Mathf.Deg2Rad) * 0.06f),
                    new Vector3(0.015f, wireL, 0.015f), EnhancedMaterials.Baseboard);
                wire.transform.localRotation = Quaternion.Euler((i - 1) * 8f, 0f, (1 - i) * 10f);
            }

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Wall-mounted HVAC ventilation intake grill.
        /// </summary>
        public static GameObject CreateVentGrill(Transform parent, Vector3 wallPos, Quaternion wallRot)
        {
            var root = new GameObject("VentGrill");
            root.transform.SetParent(parent, false);
            root.transform.position = wallPos;
            root.transform.rotation = wallRot;

            MakePart(root.transform, "GrillFace", Vector3.zero,
                new Vector3(0.85f, 0.55f, 0.02f), EnhancedMaterials.VentLouver);

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Institutional wastebasket with crumpled paper balls.
        /// </summary>
        public static GameObject CreateTrashCan(Transform parent, Vector3 position, System.Random rng)
        {
            var root = new GameObject("TrashCan");
            root.transform.SetParent(parent, false);
            root.transform.position = position;

            const float h = 0.45f, r = 0.32f;
            MakePart(root.transform, "BinBody", new Vector3(0f, h * 0.5f, 0f),
                new Vector3(r, h, r), EnhancedMaterials.PaintedMetal);

            // Crumpled paper balls inside/around
            for (int i = 0; i < 3; i++)
            {
                float ox = (float)(rng.NextDouble() - 0.5) * 0.15f;
                float oz = (float)(rng.NextDouble() - 0.5) * 0.15f;
                MakePart(root.transform, $"PaperWad_{i}", new Vector3(ox, h + 0.04f, oz),
                    new Vector3(0.08f, 0.08f, 0.08f), EnhancedMaterials.Paper);
            }

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Illuminated green EMERGENCY EXIT directional sign with soft glow.
        /// </summary>
        public static GameObject CreateExitSign(Transform parent, Vector3 position, Quaternion rotation)
        {
            var root = new GameObject("ExitSign");
            root.transform.SetParent(parent, false);
            root.transform.position = position;
            root.transform.rotation = rotation;

            // Frame
            MakePart(root.transform, "SignBody", Vector3.zero,
                new Vector3(0.65f, 0.28f, 0.08f), EnhancedMaterials.PaintedMetal);

            // Glowing face
            MakePart(root.transform, "SignFace", new Vector3(0f, 0f, -0.045f),
                new Vector3(0.58f, 0.22f, 0.01f), EnhancedMaterials.ExitSign);

            // Soft green light point
            var lightGo = new GameObject("ExitLight");
            lightGo.transform.SetParent(root.transform, false);
            lightGo.transform.localPosition = new Vector3(0f, -0.1f, -0.2f);
            var light = lightGo.AddComponent<Light>();
            light.type = LightType.Point;
            light.range = 3.5f;
            light.intensity = 0.65f;
            light.color = new Color(0.2f, 0.95f, 0.4f);
            light.shadows = LightShadows.None;

            root.isStatic = true;
            return root;
        }

        /// <summary>
        /// Horror blood spatter puddle decal on floor or wall. No collider.
        /// </summary>
        public static GameObject CreateBloodSpatter(Transform parent, Vector3 position, Quaternion rotation, Vector2 size)
        {
            var root = new GameObject("BloodSpatter");
            root.transform.SetParent(parent, false);
            root.transform.position = position;
            root.transform.rotation = rotation;

            MakePart(root.transform, "Puddle", Vector3.zero,
                new Vector3(size.x, 0.003f, size.y), EnhancedMaterials.BloodStain);

            root.isStatic = true;
            return root;
        }
    }
}
