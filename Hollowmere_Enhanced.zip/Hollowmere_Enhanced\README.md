# Hollowmere: Enhanced Edition

## Project Overview
**Hollowmere: Enhanced Edition** upgrades the visual fidelity, environmental storytelling, materials, and lighting of the procedural horror game Hollowmere while 100% preserving its working gameplay loop, player mechanics, stealth systems, and intelligent enemy AI.

- **Unity Editor Version**: `6000.6.7f1` (Unity 6.6)
- **Render Pipeline**: Built-in Render Pipeline (Standard Shader with runtime PBR maps)
- **Color Space**: Linear
- **Target Platform**: Windows Standalone (x86_64)

---

## What Was Upgraded

### 1. Advanced Procedural PBR Material Engine (`EnhancedMaterials.cs`)
The original project utilized flat procedural noise albedo on standard materials with zero normal maps or specular/metallic channels. The enhanced edition adds runtime-generated tangent-space normal maps, composite metallic-smoothness maps (`_MetallicGlossMap`), and emissive maps:
- **`FacilityWall`**: Realistic institutional concrete paneling with damp vertical water stains, horizontal expansion seams, fine concrete pitting, and normal depth.
- **`TileFloor`**: 50x50cm institutional vinyl/asbestos floor tiles with recessed dark grout lines, wear scuffing, and wet specular puddles.
- **`CeilingGrid`**: Acoustic drop ceiling panels with suspended metallic T-bars and porous sound-dampening normal texture.
- **`PaintedMetal`**: Olive-drab and gunmetal painted steel with chipped rust patches and oxidized pitting.
- **`DarkWood`**: Stained institutional desk wood with grain direction normal mapping.
- **`BloodStain`**: Arterial blood puddle decals with wet specular gleam and coagulated edge normals.
- **`VentLouver`**: Slotted industrial HVAC intake grills.
- **`HazardStripe` & `HighVoltage`**: Safety chevron caution plates and high-voltage warning placards.
- **`Biohazard`**: Quarantine and containment warning emblems.
- **`Whiteboard`**: Dry-erase research boards with vital graphs and scribbles.
- **`ExitSign`**: Glowing emergency exit signs with green emissive backlight.
- **`EpoxyResin` & `ChemicalGlass`**: Laboratory countertop resin and translucent chemical glassware.

### 2. Compound Procedural Architectural & Furniture Props (`FacilityProps.cs`)
Replaced monolithic blocky shapes with compound, detailed facility props:
- **Office Desks**: Dark wood tops, metal modesty panels, square steel legs, 3-drawer pedestals with chrome handles, warm incandescent desk lamps, and scattered paperwork.
- **Swivel / Institutional Chairs**: 5-star wheeled bases, chrome cylinders, vinyl seats, and curved backrests.
- **Filing Cabinets**: 4-drawer vertical steel cabinets with chrome handles, label cards, and partially open drawers with visible file folders.
- **Industrial Shelving Units**: Slotted angle-iron frames stocked with cardboard archive boxes, chemical canisters, and binders.
- **Hospital / Examination Cots**: Stainless steel frames on casters, vinyl examination mattresses with inclined headrests, and IV drip pole stands.
- **Fluorescent Fixtures**: Suspended dual-tube fluorescent fixtures with sheet metal casings, glowing tubes, cool white/cyan hospital light (`(0.85, 0.92, 0.90)`), soft shadows, and subtle electrical flickers.
- **Overhead Conduits & Pipes**: Industrial conduit runs with flange joint rings every 2 meters.
- **Hanging Cables**: Drooping electrical wires dangling from ceiling junction boxes.
- **HVAC Vents & Wall Plaques**: Framed emergency evacuation schematics, biohazard placards, and wall intake grills.
- **Doorway Portals**: Beveled metal door jambs and lintels with hazard caution stripes at all corridor-to-room transitions.
- **Floor Debris**: Scattered patient records, memos, crumpled paper wads, and metal wastebaskets.

### 3. Procedural Room & Corridor Dressing (`RoomDecorator.cs`)
- **Architectural Baseboards**: Dark rubber/metal trims along the base of all exposed interior walls, eliminating floating seams.
- **Thematic Room Dressing**:
  - **Start Room**: Security / Reception Office (desks, chairs, ajar filing cabinet, evacuation plan, wastebasket, floor paperwork).
  - **Medical Wards**: Examination cots, IV poles, blood stains, biohazard placards, vents.
  - **Storage & Maintenance Bays**: Industrial shelving rows, archive boxes, storage crates, high-voltage plates.
  - **Research Labs**: Lab benches with chemical reagent bottles, research whiteboards, filing cabinets.
  - **Corridors**: Overhead pipes, hanging wires, doorway portals, floor debris, and illuminated emergency EXIT signs.

---

## Preservation of Gameplay, AI, and Performance

1. **Intelligent Enemy AI Line-of-Sight Integrity**:
   - `Entity.cs` casts raycasts with `QueryTriggerInteraction.Ignore`.
   - **Critical Rule**: All decorative clutter (pipes, hanging wires, lamps, wall frames, baseboards, floor papers, blood puddles) has colliders removed (`Destroy(col)`).
   - Only dedicated tactical cover props (desks, filing cabinets, shelving units) possess solid `BoxCollider` components, matching the stealth mechanics of the original crates.
2. **Grid Pathfinding & Doorway Clearance**:
   - Heavy furniture anchors strictly against **solid perimeter walls and corners**, leaving room centers (patrol paths) and corridor openings 100% unobstructed.
3. **Lighting & CPU Performance**:
   - `PlayerStatus.cs` iterates over active scene lights every 5s. To prevent CPU frame drops, light sources are restricted to primary room fixtures (fluorescent fixture + soft desk lamp) while secondary fixtures use self-illuminated emissive materials without dynamic light components.
4. **Draw Calls & Static Batching**:
   - All generated static geometry and props are marked `isStatic = true`, allowing `StaticBatchingUtility.Combine` to collapse them into combined batches for silky-smooth 60+ FPS on Ultra settings.

---

## File Manifest

### Newly Added Files:
- `Assets/Scripts/Gen/EnhancedMaterials.cs`: Procedural PBR material generator (Normal maps, metallic-gloss, emissive).
- `Assets/Scripts/Gen/FacilityProps.cs`: Compound procedural prop library (desks, cots, cabinets, shelves, lights, pipes).
- `Assets/Scripts/Gen/RoomDecorator.cs`: Architectural baseboards, doorway frames, and thematic room dressing.
- `Assets/Editor/EnvironmentUpgradeTester.cs`: Unity Editor test runner (`Hollowmere > Test Full Environment Generation`).
- `README.md`: This comprehensive documentation file.

### Modified Files:
- `Assets/Scripts/Gen/LevelGenerator.cs`:
  - Added `Rooms` list to `LevelData`.
  - Populated `Rooms` during `GenerateData`.
  - Upgraded `BuildGeometry` to use `EnhancedMaterials.TileFloor`, `EnhancedMaterials.CeilingGrid`, `EnhancedMaterials.FacilityWall`, and integrated `RoomDecorator.DecorateFacility`.

---

## How to Open in Unity Hub

1. Extract `Hollowmere_Enhanced.zip` to your desired directory (e.g. `C:\Projects\Hollowmere_Enhanced`).
2. Open **Unity Hub**.
3. Click the **Add** button (or down-arrow next to Add -> **Add project from disk**).
4. Select the extracted `Hollowmere_Enhanced` folder (the folder containing `Assets`, `Packages`, and `ProjectSettings`).
5. Select Unity Editor version **`6000.6.7f1`** (or compatible Unity 6.x editor).
6. Open the project. Unity will import assets and open cleanly.
7. Open scene `Assets/Scenes/Main.unity` (deliberately empty boot scene).
8. Press **Play** in the Unity Editor to launch the run!

---

## Verification & Testing Status

- **Compilation Status**: Verified. Domain reloads cleanly with zero compilation errors and zero warnings.
- **Procedural Assembly**: Verified. Generated test layout confirms successful instantiation of walls, architectural baseboards, doorway frames, compound furniture props, fluorescent fixtures, and static batching combination.
- **Level Invariant Verification**: Available via top menu `Hollowmere > Validate Level Generation` (validates layout solvability across 500 seeds).
- **In-Editor Test**: Available via top menu `Hollowmere > Test Full Environment Generation`.
